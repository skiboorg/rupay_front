Examples for command files for start with forging and loop restart.

Copy bath-file to root folder for use it.

Start commands help in file readme-commands.txt