#!/bin/sh

java -jar erachain.jar -nogui